import 'dart:io';
void main()
{
  print("Enter first Name:");
  var fNm=stdin.readLineSync();

  print("Enter second name:");
  var sNm=stdin.readLineSync();

  print('name: $sNm, $fNm');

}