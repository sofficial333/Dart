import 'dart:io';

void main()
{
  print(Platform.version);
}