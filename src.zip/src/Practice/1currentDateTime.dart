void main()
{
  main() {
    var now = new DateTime.now();
    print(now);
  }
}