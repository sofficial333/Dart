/*WADP  to display the first and last colors from the following list.
color_list = ["Red","Green","White" ,"Black"] */

void main()
{
   var color_list=['red','green','white','black'];
   
   print('${color_list[0]} and ${color_list.last}');
}