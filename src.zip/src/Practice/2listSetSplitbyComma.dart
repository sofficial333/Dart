// WADP  which accepts a sequence of comma-separated numbers from user and generate a list and a tuple with those numbers. Sample data : 3, 5, 7, 23 Output : List : ['3', ' 5', ' 7', ' 23'] Set : ('3', ' 5', ' 7', ' 23')
//
//
// import 'dart:io';
// main() {
//   var elements = stdin.readLineSync();
//   var eleList = elements.split(',');
//   print('List: $eleList');
//   var eleSet = <String> {};
//   for (var x in eleList) {
//     eleSet.add(x);
//   }
//   print('Set: $eleSet');
// }
