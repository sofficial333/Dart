import 'dart:collection';
void main()
{
  Queue<String> Example_queue=new Queue<String>();

  print(Example_queue);
  Example_queue.add('This');
  Example_queue.add('is');
  Example_queue.add('a');
  Example_queue.add('Queue');
  print(Example_queue);
}