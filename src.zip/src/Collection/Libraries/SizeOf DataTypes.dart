void main()
{
  int a=-10;
  double b=10.55465132465451324688465415;

  print('a=$a');
  print('b=$b');
}