void main() {
  List<String> subjects = ["DSA", "OS", "DBMS", "\$",'C language','12345'];
  subjects.forEach((var subject)=> print("I love ${subject}"));
}