void main() {
  // Recursive function to calculate the factorial of a number
  int factorial(int n) {
    if (n <= 1) {
      return 1;
    } else {
      return n * factorial(n - 1);
    }
  }

  // Calling the recursive function
  print("Factorial of 5 is: ${factorial(5)}");
}
