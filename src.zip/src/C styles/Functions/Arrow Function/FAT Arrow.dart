int multiply(int a, int b) => a * b;

void main() {
  print(multiply(4, 5)); // Outputs: 20
}