void main() {
  // Arrow function to calculate the cube of a number
  int cube(int num) => num * num * num;

  // Calling the function and printing the result
  print("The cube of 3 is: ${cube(3)}");
}
