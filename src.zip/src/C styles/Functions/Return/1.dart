void main()
{
  int add(int a, int b)
      {
        int c=a+b;
        return c;
      }
  int su= add(4,5);
print(su);
}