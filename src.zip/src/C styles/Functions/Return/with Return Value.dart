void main() {
  // Function that calculates the square of a number
  int square(int num)
  {
    int square = num * num;
    return square; //function returning
  }

  // Calling the function and printing the result
  int fourSq = square(4);
  print("The square of 4 is: $fourSq");
}