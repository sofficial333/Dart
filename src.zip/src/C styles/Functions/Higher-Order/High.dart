void main() {
  // Passing a function as a parameter
  List<int> numbers = [1, 2, 3];
  numbers.forEach(printDouble); // Calls printDouble for each number
}

void printDouble(int number) {
  print(number * 2);
}