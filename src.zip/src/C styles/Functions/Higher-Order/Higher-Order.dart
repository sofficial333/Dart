void main() {
  // A function that accepts a function as a parameter
  void applyFunction(int num, Function operation) {
    print("Result: ${operation(num)}");
  }

  // Passing different functions as arguments
  applyFunction(5, (x) => x * x); // Passing a lambda function
  applyFunction(5, (x) => x + 10); // Another lambda function
}
