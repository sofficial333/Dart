void main() {
  int sum = add(5, 10);
  print("Sum: $sum");
}

int add(int a, int b) {
  return a + b;
}