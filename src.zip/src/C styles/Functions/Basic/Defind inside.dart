void main() {
  // Function definition
  void greet()
  {
    print("Hello, welcome to Dart!");
  }
  // Function call
  greet();
}
