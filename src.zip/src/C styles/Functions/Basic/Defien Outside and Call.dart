void main()
{
  greet();    // Function call
}

void greet()    // Function definition
{
  print("Hello, welcome to Dart!");
}