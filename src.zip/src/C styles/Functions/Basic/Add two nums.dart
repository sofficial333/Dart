int add(int a, int b) {
  return a + b;
}

void main() {
  int result53 = add(5, 3);   // function calling
  print("The result is: $result53");

  int result32 = add(3,2);    // function calling
  print("The result is: $result32");
}
