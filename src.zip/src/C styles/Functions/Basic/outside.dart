void main()
{
  display(); //calling
}

display()
{
  print('defining outside'); //Defining
}