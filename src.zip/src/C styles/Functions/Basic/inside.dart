void main()
{
  void display()  // Defining
  {
    print('Function define inside');    //defined than calling
  }

  display(); //calling

}