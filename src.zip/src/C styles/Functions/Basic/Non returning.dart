void greet(String name) {
  print("Hello, $name!");
}

void main() {
  greet("Alice");
}