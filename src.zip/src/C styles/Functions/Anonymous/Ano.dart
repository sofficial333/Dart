void main() {
  // List of numbers
  List<int> numbers = [1, 2, 3, 4, 5];

  // Anonymous function passed to forEach
  numbers.forEach((num) {
    print("Number: $num");
  });
}
