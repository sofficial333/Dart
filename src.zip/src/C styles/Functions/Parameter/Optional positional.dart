void describe(String name, [int? age])
{
  if (age != null) {
    print("$name is $age years old.");
  } else
  {
    print("Name is $name.");
  }
}

void main() {
  describe("Bob", 25);
  describe("Alice"); // without passing age parameter
}