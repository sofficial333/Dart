void main()
{
  disply('Sandeep');
  disply('pradeep');
}

void disply(String name)
{
  print('Name is: $name');
}