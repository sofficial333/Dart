void main()
{
  course('android', 'flutter'); //both are required to call
}

void course(String course1, String course2)  //bydefault required function
{
  print('course1 is $course1');
  print('course2 is $course2');
}