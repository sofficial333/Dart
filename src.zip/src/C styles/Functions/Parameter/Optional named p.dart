void main()
{
  int data= volume(3,width:2, length:4);
  print(data);
}

int volume(int height, {int? width, int? length})=> length!*width!*height;