void main()
{
  int v=vol(2,4);
  print(v);
}

  int vol(int l, int b,{int h=3})=> l*b*h;