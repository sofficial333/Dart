void main() {
  // Function that takes a name and prints a personalized message
  void greet(String name)  // name as parameter
  {
    print("Hello, $name! Welcome to Dart!");
  }

  // Calling the function with an argument
  greet("Alice"); // calling with parameter
  greet("Bob");
}
