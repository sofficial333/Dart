void main() {
  // Function with optional positional parameter
  void greet(String name, [String? message]) {
    if (message != null) {
      print("$message, $name!");
    } else {
      print("Hello, $name!");
    }
  }

  // Calling the function with and without the optional parameter
  greet("Alice");
  greet("Bob", "Good morning");
}
