void greet(String name, [String greeting = "Hello"]) {
  print("$greeting, $name!");
}

void main() {
  greet("Alice"); // Uses default greeting
  greet("Bob", "Hi"); // Uses provided greeting
}