void main() {
  // Function with optional named parameters
  void describePerson({String? name, int? age}) {
    print("Name: ${name ?? "Unknown"}, Age: ${age ?? 0}");
  }

  // Calling the function with named parameters
  describePerson(name: "Alice", age: 25);
  describePerson(age: 30);
}
