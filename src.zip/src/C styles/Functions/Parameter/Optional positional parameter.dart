void main()
{
course('c', 'c++');
course('c', 'c++','java');
}

course(String c1, String c2, [String? c3])
{
  print('courses are $c1, $c2, $c3');
}