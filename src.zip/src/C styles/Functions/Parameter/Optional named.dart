void displayInfo({String? name, int? age}) {
  print("Name: $name, Age: $age");
}

void main() {
  displayInfo(name: "John", age: 30);
  displayInfo(age: 22, name: "Emma"); // order doesn't matter
}
