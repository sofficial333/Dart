void main()
{
  int a=10;
  int b=1,i,j;
  (i=a+b)??(j=a-b);
}