void main() {
  int age = 5;

  if (age >= 18) {
    print("You are an adult.");
  } else if (age >= 13) {
    print("You are a teenager.");
  } else {
    print("You are a child.");
  }
}


// import 'dart:io';
//
// void main()
// {
//   print('Enter marks !!!');
//   int nm=int.parse(stdin.readLineSync()!);
//
//   if(nm>=60 && nm<=100)
//     {
//       print('first Division');
//     }
//   else if(nm>=40 && nm<=60)
//     {
//       print('Third Division');
//     }
//   else if(nm>=40 && nm<=33)
//     {
//       print('Third Division');
//     }
//   else if(nm<33)
//     {
//       print('Failed !!');
//     }
//   else
//     {
//       print('Invalid input');
//     }
// }