// import 'dart:io';
//
// void main() {
//   print('Enter a number');
//   int i = int.parse(stdin.readLineSync()!);
//
//   if (i % 2 == 0) {
//     print('$i is Even number');
//   }
//   else {
//     print('$i is odd number');
//   }
// }

void main() {
  int temperature = 35;

  if (temperature > 30) {
    print("It's hot outside.");
  } else {
    print("The weather is cool.");
  }
}
