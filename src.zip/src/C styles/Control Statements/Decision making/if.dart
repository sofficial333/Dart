// void main(){
//   int i=16;
//
//   if(i>15)
//     {
//       print("$i is Greater than 15");
//     }
//   print('i am not in the if condition, Thank you!!!!!');
// }

import 'dart:io';

void main() {

  print('Enter you score');
  int score = int.parse(stdin.readLineSync()!);

  if (score != null) {
    print("Great job! You scored $score % marks");
  }
}
