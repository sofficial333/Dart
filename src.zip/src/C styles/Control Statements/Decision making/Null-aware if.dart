import 'dart:io';
void main() {
  String? name;

  // Use ?? operator to provide a default value if `name` is null
  print("Hello, ${name ?? "Guest"}");
}
