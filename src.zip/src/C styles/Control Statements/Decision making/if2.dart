void main()
{
  bool b=true;
  if(b==true)
    {
      print('true');
    }
}