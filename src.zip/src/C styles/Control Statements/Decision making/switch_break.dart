void main() {
  String grade = "A";

  switch (grade) {
    case "A":
      print("Excellent!");
      break;
    case "B":
      print("Good job!");
      break;
    case "C":
      print("Fair.");
      break;
    default:
      print("Needs improvement.");
  }
}


// import 'dart:io';
//
// void main()
// {
//   var m1 = 10;
//   var m2 = 3;
//   // m1~/=m2;
//   // print("Result is ${m1~/=m2}");
//
//   print('Enter Day');
//   int nm =  int.parse(stdin.readLineSync()!);
//   switch(nm) {
//     case 1:
//       print("Monday");
//       break;
//     case 2:
//       print('Tuesday');
//       break;
//     case 3:
//       print("Wednusday");
//       break;
//     case 4:
//       print('thursday');
//       break;
//     case 5:
//       print('friday');
//       break;
//     case 6:
//       print('saturday');
//       break;
//     case 7:
//       print('sunday');
//       break;
//     default:
//       print('Not a valid date');
//       break;
//   }
// }