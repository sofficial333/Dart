void main() {
  int number = -8;

  if (number > 0) {
    if (number % 2 == 0) {
      print("$number is positive and even.");
    } else {
      print("$number is positive and odd.");
    }
  } else {
    print("$number is not positive.");
  }
}
