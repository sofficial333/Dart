import 'dart:io';

void main()
{
  // int a=1;
  print('Enter between 1 to 5 number');
  int b=int.parse(stdin.readLineSync()!);

  switch(b)
  {
    case 1:{
      print('one');
      break;
    }
    case 2:
      {
        print('two');
        break;
      }
    case 3:
      {
        print('three');
        break;
      }
    case 4:
      {
        print('four');
      }
    default:
      {
        print('wrong entry');
      }
    }

  }