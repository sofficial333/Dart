void main() {
  int age = 20;

  String result = (age >= 18) ? "You are eligible to vote." : "You are not eligible to vote.";
  print(result);
}
