import 'dart:io';

void main()
{
  int i = 1,sum = 0;
  // while(i<=5)
  //   {
  //     sum = sum+i;
  //     print(i);
  //     i++;
  //   }
  //
  //   print("sum is $sum");


  // do{
  //   print(i);
  //   i++;
  // }while(i<=10);

  // for(int j = 1 ;j<=10;j++)
  //   {
  //     print(j);
  //   }

  var list = <int>[88,77,29,20,21,89];
  for(var lst in list)
    {
      print(lst);
    }

}