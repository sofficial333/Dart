void main()
{
  int a=9, b=88;

  a>b?print("a is grater"):print("b is greater");
}