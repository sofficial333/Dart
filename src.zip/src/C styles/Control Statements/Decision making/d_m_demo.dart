import 'dart:io';

void main()
{
  print("Enter marks!!!!!!");
  int nm =  int.parse(stdin.readLineSync()!);

  if(nm >= 90 && nm <= 100)
    {
      print("First Div");
    }

  else if(nm >= 75 && nm <= 90)
    {
      print("Second div");
    }


  else if(nm >= 45 && nm <= 75)
  {
    print("Third div");
  }

  else
    {
      print("Better luck next time");
    }
}