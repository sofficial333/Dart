void main()
{
  for(int a=0;a<=6;a++)
  {
    print(a);
    if(a==3){
      break;
    }
  }
}