void main() {
  for (int i = 1; i <= 5; i++) {
    if (i == 3) {
      continue;  // Skip this iteration when i is 3
    }
    print("Number: $i");
  }
}
