void main() {
  for (int i = 1; i <= 5; i++) {
    if (i == 3) {
      break;  // Exit the loop when i is 3
    }
    print("Number: $i");
  }
}
