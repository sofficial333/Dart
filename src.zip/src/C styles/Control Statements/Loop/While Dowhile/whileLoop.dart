void main() {
  int i = 0;
  while(i < 5) {
    print('Hello Sandeep number ${i + 1}');
    i++;
  }
}