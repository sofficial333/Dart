void main() {
  int count = 1;

  // Print numbers until count reaches 5
  while (count <= 5) {
    print("Count: $count");
    count++;
  }
}


// void main()
    // {
    //   int i=1, numb=9;
    //
    //   while(i<=numb)
    //     {
    //       print('Hello');
    //       i=i+1;
    //     }
    // }