void main() {
  int a = 0,
      b = 0;
  while (b <= 4) {
    print(b);
    b++;
  }
  do {
    print(a);
    a++;
  } while (a <= 6);
}