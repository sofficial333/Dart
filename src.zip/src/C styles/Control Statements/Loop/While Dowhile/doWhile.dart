// void main() {
//   int i = 0;
//   do{
//
//     print("Welcome ji no ${i}");
//     i++;
//   }while(i < 7);
// }

void main() {
  int number = 1;

  // Print numbers until number exceeds 3
  do {
    print("Number: $number");
    number++;
  } while (number <= 3);
}
