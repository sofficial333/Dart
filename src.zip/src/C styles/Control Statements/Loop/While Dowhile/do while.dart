void main()
{
  int a=0;
  do
  {
    print(a);
    a++;
  }while(a<=6);
}