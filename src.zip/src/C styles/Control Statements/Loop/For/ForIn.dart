void main()
{
  List<String> subjects = ["DSA", "OS", "DBMS", "CN"];
  for(String sub in subjects){
    print("I love ${sub}");
  }
}

