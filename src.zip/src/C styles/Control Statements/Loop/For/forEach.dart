void main()
{
  Map<int, String> student={1:'sandeep',2:'pradeep',3:'pooja'};

  student.forEach((roll, name)
  {
    print('roll:$roll, name=$name');
  });
}
