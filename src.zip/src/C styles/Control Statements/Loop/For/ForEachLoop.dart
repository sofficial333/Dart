void main() {
  List<String> subjects = ["DSA", "OS", "DBMS", "CN"];
  subjects.forEach((var subject)=> print("I love ${subject}"));
}