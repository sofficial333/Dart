// void main()
// {
//   var lst=[0,1,2,3,4,5,6,7];
//
//   lst.forEach((var num)
//       {
//         print(num);
//       });
// }

void main() {
  Set<int> numbers = {10, 20, 30, 30};

  // Apply a function to each element in the list
  numbers.forEach((num) {
    print("Number: $num");
  });
}
