void main() {
  for (int i = 0; i < 5; i++) {
    print('Hello Sandeep number ${i + 1}');
  }
}