import 'dart:io';
void main() {
  print("Enter a sentence:");
  String? sentence = stdin.readLineSync();

  int wordCount = sentence!.split(" ").length;
  print("The number of words in the sentence is: $wordCount");
}