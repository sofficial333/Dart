import 'dart:io';
void main() {
  print("Enter a word:");
  String? word = stdin.readLineSync();

  String reversedWord = word!.split('').reversed.join('');
  if (word == reversedWord) {
    print("$word is a palindrome.");
  } else {
    print("$word is not a palindrome.");
  }
}