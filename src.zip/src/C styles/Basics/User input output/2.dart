import 'dart:io';

void main() {
  String nm;
  int ag;
  double per;

  List<int> lst;
  Set<String> str;

  print('Enter your name-');
  nm = stdin.readLineSync()!;
  print('Name is -$nm');

  print('Enter your age-');
  ag = int.parse(stdin.readLineSync()!);
  print('Age is- $ag');

  print('Enter your 10th percentage-');
  per = double.parse(stdin.readLineSync()!);
  print('10th percentage is-$per');
}