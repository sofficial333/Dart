import 'dart:io';

void main() {
  print("Enter the numerator:");
  double num1 = double.parse(stdin.readLineSync()!);

  print("Enter the denominator:");
  double num2 = double.parse(stdin.readLineSync()!);

  if (num2 == 0) {
    print("Cannot divide by zero.");
  } else {
    double result = num1 / num2;
    print("The result is: $result");
  }
}

