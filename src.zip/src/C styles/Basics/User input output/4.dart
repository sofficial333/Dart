import 'dart:io';

void main() {
  // Request input from the user
  print("Enter your name:");
  String? name = stdin.readLineSync();  // Takes input as a string

  // Output the input
  print("Hello, $name!");
}