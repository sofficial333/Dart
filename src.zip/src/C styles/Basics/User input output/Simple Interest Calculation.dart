import 'dart:io';

void main() {
  print("Enter the principal amount:");
  double principal = double.parse(stdin.readLineSync()!);

  print("Enter the rate of interest:");
  double rate = double.parse(stdin.readLineSync()!);

  print("Enter the time in years:");
  double time = double.parse(stdin.readLineSync()!);

  double interest = (principal * rate * time) / 100;
  print("The simple interest is: $interest");
}