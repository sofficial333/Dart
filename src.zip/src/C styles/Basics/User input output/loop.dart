import 'dart:io';

void main() {
  int? age;

  // Repeat until valid input is given
  while (age == null) {
    print("Please enter your age:");
    String? input = stdin.readLineSync();

    try {
      age = int.parse(input!);
      print("Your age is $age years.");
    } catch (e) {
      print("Invalid input. Please enter a valid number.");
    }
  }
}