import 'dart:io';
void main() {
  print("Enter numbers separated by spaces:");
  String? input = stdin.readLineSync();

  List<String> numbers = input!.split(" ");
  int sum = 0;

  for (String number in numbers) {
    sum += int.parse(number);
  }
  print("The sum of the numbers is: $sum");
}