import 'dart:io';

void main() {
  // Take name as input
  print("Enter your name:");
  String? name = stdin.readLineSync();

  // Take age as input and convert to integer
  print("Enter your age:");
  int age = int.parse(stdin.readLineSync()!);

  // Calculate future age
  int futureAge = age + 5;
  print("Hello, $name! In 5 years, you will be $futureAge years old.");
}