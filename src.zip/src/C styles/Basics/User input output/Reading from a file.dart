import 'dart:io';

void main() async {
  var file = File('output.txt');

  // Reading content from the file
  String content = await file.readAsString();

  print("File content: $content");
}
