import 'dart:io';

void main()
{
  var list = <int>[];
  for(int i = 0; i<=5 ;i++)
    {
      print("Enter $i data");
      int nm =  int.parse(stdin.readLineSync()!);
      list.add(nm);
    }


 for(var itm in list)
   {
     print(itm);
   }
}