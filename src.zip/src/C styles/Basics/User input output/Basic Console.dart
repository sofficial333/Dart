import 'dart:io';

void main() {
  // Output
  print('Enter your name:');

  // Input
  String? name = stdin.readLineSync();

  // Output
  print('Hello, $name!');
}
