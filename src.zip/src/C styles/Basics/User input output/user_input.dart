import 'dart:io';

void main()
{
  print("Enter name");
  String nem = stdin.readLineSync()!;
  print("Name is $nem");

  print('Enter age');
  int nm =  int.parse(stdin.readLineSync()!);
  print("Age is $nm");

}