
void main(List<String> arguments) {
  if (arguments.isEmpty) {
    print("No arguments passed.");
  } else {
    print("Arguments passed: ${arguments.join(", ")}");
  }
}
