import 'dart:io';

void main() {
  print("Enter a number:");
  String? input = stdin.readLineSync();

  try {
    int number = int.parse(input!);
    print("You entered the number: $number");
  } catch (e) {
    print("Invalid input. Please enter a valid number.");
  }
}