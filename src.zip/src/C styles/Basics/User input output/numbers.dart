import 'dart:io';

void main() {
  print("Enter your age:");
  String? input = stdin.readLineSync();

  // Convert the string input to an integer
  int age = int.parse(input!);  // Ensure the input is non-null

  print("Your age is $age years.");
}