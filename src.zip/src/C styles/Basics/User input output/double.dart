import 'dart:io';

void main() {
  print("Enter a decimal number:");
  double number = double.parse(stdin.readLineSync()!);
  print("You entered: $number");
}