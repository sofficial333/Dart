//we can take user input using the dart:io library.
import 'dart:io';

void main() {
  // Taking an integer input
  print("Enter your age:");
  int age = int.parse(stdin.readLineSync()!);
  print("You entered age: $age");

  // Taking a double input
  print("Enter your height in meters:");
  double height = double.parse(stdin.readLineSync()!);
  print("You entered height: $height meters");

  // Taking a string input
  print("Enter your name:");
  String name = stdin.readLineSync()!;
  print("Hello, $name!");

  // Taking a boolean input
  print("Are you a student? (yes/no):");
  String isStudentInput = stdin.readLineSync()!.toLowerCase();
  bool isStudent = isStudentInput == 'yes';
  print("Student status: $isStudent");

  // Taking a list of numbers (comma-separated)
  print("Enter a list of numbers separated by commas:");
  String numbersInput = stdin.readLineSync()!;
  List<int> numbers = numbersInput.split(',').map(int.parse).toList();
  print("You entered the numbers: $numbers");

  // Calculating and outputting some derived values
  int nextAge = age + 1;
  double heightInCm = height * 100;
  print("Next year, you will be $nextAge years old.");
  print("Your height in centimeters is $heightInCm cm.");
}
