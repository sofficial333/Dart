import 'dart:io';

void main() async {
  var file = File('output.txt');

  // Writing text to the file
  await file.writeAsString('Hello, Dart!');

  print("Text has been written to output.txt.");
}