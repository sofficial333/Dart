import 'dart:io';

void main() {
  while (true) {
    print('Enter a number (or type "exit" to quit):');
    String? input = stdin.readLineSync();

    if (input == 'exit') {
      print('Goodbye!');
      break;
    }

    int? number = int.tryParse(input!);
    if (number != null) {
      print('You entered: $number');
    } else {
      print('Please enter a valid number.');
    }
  }
}
