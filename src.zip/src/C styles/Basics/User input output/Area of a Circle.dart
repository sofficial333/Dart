import 'dart:io';
void main() {
  print("Enter the radius of the circle:");
  double radius = double.parse(stdin.readLineSync()!);

  double area = 3.14159 * radius * radius;
  print("The area of the circle is: $area");
}

