import 'dart:io';

void main() {
  String name = getName(); //function
  int age = getAge();  //function

  print('Hello, $name! You are $age years old.');
}

String getName() {
  print('Enter your name:');
  return stdin.readLineSync()!;
}

int getAge() {
  print('Enter your age:');
  String? ageInput = stdin.readLineSync();
  return int.tryParse(ageInput!) ?? 0;
}
