
import 'dart:io';

void main() {
  print("Enter a number to find its square:");
  int num = int.parse(stdin.readLineSync()!);

  int square = num * num;
  print("The square of $num is: $square");
}