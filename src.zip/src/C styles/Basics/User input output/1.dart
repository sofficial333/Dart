import 'dart:io';

void main(){
  int no;
  String st;
  double db;

  print ('Enter name');
  st=stdin.readLineSync()!;
  print('Name is $st');

  print ('Enter a number');
  no=int.parse(stdin.readLineSync()!);
  print('number is $no');

  print ('enter string/ Double value');
  db=double.parse(stdin.readLineSync()!);
  print ('Double value is $db');
}