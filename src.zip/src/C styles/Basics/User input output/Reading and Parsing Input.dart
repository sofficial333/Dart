import 'dart:io';

void main() {
  print('Enter your age:');

  String? input = stdin.readLineSync();
  int? age = int.tryParse(input!);

  if (age != null) {
    print('You are $age years old.');
  } else {
    print('Invalid input. Please enter a number.');
  }
}
