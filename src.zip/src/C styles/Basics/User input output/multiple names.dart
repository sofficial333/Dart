
import 'dart:io';

void main() {
  print("Enter three names, separated by commas:");
  String? input = stdin.readLineSync();
  List<String> names = input!.split(',');

  for (var name in names) {
    print("Hello, $name!");
  }
}

