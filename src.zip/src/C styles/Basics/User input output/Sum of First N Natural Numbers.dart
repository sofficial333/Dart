
import 'dart:io';

void main() {
  print("Enter a number N to find the sum of first N natural numbers:");
  int num = int.parse(stdin.readLineSync()!);

  int sum = (num * (num + 1)) ~/ 2;
  print("The sum of first $num natural numbers is $sum.");
}

