import 'dart:io';

void main() {
  try {
    print("Enter your age:");
    int age = int.parse(stdin.readLineSync()!);
    print("You are $age years old.");
  } catch (e) {
    print("Invalid input. Please enter a valid integer.");
  }
}