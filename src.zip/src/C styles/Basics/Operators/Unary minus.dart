void main()
{
  var a=-5;
  var b=7;
  print("Unery of a is: ${-a}");
  print("Unery of a is: ${-b}");
}