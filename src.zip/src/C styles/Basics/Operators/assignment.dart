void main()
{
  int a=1; //assign
  int b=1;
  a=a+1; //increse and assign
  b+=1;
  print(a);
  print(b);
}