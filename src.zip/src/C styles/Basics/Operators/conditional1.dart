void main()
{
  var a=39;
  var output=a>38?"Greater than 38":"Lesser than 38";
  print(output);
}