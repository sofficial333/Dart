void main()
{
  bool a=false, b=true;

  print(a&b);
  print(a|b);
  // print(~a); Error
  print(a^b);
  // print(a>>b); Error
  // print(a<<b);

}