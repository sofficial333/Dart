void main() {
  dynamic variable = 'Hello';

  print(variable is String); // true
  print(variable is! int); // true
}
