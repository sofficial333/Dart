void main() {
  StringBuffer sb = StringBuffer();

  sb
    ..write('Hello, ')
    ..write('world!')
    ..write(' Dart is great.');

  print(sb.toString()); // Hello, world! Dart is great.
}
