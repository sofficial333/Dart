void main()
{
  int a=33;
  double b=2.2;
  String c="san";

  print( a is int);
  print(b is int);
  print(c is! String);
}