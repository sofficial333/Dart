void main() {
  int z = 5;

  z += 3; // z = z + 3
  print('After += : $z'); // 8

  z -= 2; // z = z - 2
  print('After -= : $z'); // 6
  z *= 2; // z = z * 2
  print('After *= : $z'); // 12
  z ~/= 3; // z = z ~/ 3
  print('After ~/= : $z'); // 4
  z %= 2; // z = z % 2
  print('After %= : $z'); // 0
}