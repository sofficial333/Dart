void main() {
  int a = 10;
  a--;
  print("Decremented Value: $a");
}
