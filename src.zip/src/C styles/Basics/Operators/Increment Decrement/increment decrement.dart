void main()
{
  int a=5;
  int b=5;
  // print(++a);
  // print(b++);

print(--a);
print(b--);
}