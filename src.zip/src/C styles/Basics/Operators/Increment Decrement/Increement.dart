void main() {
  int a = 10;
  a++;
  print("Incremented Value: $a");
}