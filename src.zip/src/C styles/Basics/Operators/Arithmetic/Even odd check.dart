void main() {
  int number = 15;
  print(number % 2 == 0 ? "Even" : "Odd");
}