void main()
{
  var n=1, m=2;

  print('n+m=${n+m}');
  print('n-m=${n-m}');
  print('n*m=${n*m}');
  print('n/m=${n/m}');
  print('n%m=${n%m}');
}