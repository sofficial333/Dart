void main() {
  int a = 5, b = 10;
  a = a + b;
  b = a - b;
  a = a - b;
  print("After swapping: a = $a, b = $b");
}
