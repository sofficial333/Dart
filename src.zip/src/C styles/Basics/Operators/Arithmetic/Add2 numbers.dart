void main() {
  int a = 10, b = 20;
  int sum = a + b;
  print("Sum: $sum");
}
