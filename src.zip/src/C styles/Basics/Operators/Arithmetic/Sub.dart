void main() {
  int a = 30, b = 15;
  int difference = a - b;
  print("Difference: $difference");
}