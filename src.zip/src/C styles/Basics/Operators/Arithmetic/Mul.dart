void main() {
  int a = 7, b = 6;
  int product = a * b;
  print("Product: $product");
}