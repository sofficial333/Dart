void main() {
  double weight = 70; // in kg
  double height = 1.75; // in meters
  double bmi = weight / (height * height);
  print("BMI: $bmi");
}