void main() {
  int length = 10, width = 5;
  int perimeter = 2 * (length + width);
  print("Perimeter: $perimeter");
}
