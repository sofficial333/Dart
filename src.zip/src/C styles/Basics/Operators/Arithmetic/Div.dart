void main() {
  double a = 22, b = 7;
  double quotient = a / b;
  print("Quotient: $quotient");
}