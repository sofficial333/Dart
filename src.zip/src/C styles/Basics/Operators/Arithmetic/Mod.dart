void main() {
  int a = 17, b = 5;
  int remainder = a % b;
  print("Remainder: $remainder");
}