import 'dart:math';

void main() {
  int base = 2, exponent = 3;
  int power = pow(base, exponent) as int;
  print("$base^$exponent = $power");
}