void main() {
  double a = 4, b = 7, c = 9, d = 12, e = 15;
  double average = (a + b + c + d + e) / 5;
  print("Average: $average");
}