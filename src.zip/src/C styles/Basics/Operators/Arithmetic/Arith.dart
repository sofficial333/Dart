void main() {
  int a = 10;
  int b = 3;
  print('Addition: ${a + b}'); // 13
  print('Subtraction: ${a - b}'); // 7
  print('Multiplication: ${a * b}'); // 30
  print('Division: ${a / b}'); // 3.3333
  print('Integer Division: ${a ~/ b}'); // 3
  print('Modulus: ${a % b}'); // 1
}