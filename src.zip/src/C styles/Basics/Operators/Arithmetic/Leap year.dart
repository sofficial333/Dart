void main() {
  int year = 2024;
  print((year % 4 == 0 && year % 100 != 0) || year % 400 == 0 ? "Leap Year" : "Not a Leap Year");
}