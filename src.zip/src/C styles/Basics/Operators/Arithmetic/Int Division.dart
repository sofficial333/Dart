void main() {
  int a = 17, b = 5;
  int quotient = a ~/ b;
  print("Quotient (integer division): $quotient");
}