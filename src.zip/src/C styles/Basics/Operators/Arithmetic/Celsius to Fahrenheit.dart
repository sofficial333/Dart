void main() {
  double celsius = 25;
  double fahrenheit = (celsius * 9 / 5) + 32;
  print("$celsius°C = $fahrenheit°F");
}