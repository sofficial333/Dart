void main() {
  double radius = 7;
  double area = 3.14 * radius * radius;
  print("Area of Circle: $area");
}