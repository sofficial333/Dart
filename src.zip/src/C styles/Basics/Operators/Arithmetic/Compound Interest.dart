void main() {
  double principal = 1000, rate = 5, time = 2;
  double amount = principal * (1 + (rate / 100)) * time;
  print("Compound Interest: ${amount - principal}");
}