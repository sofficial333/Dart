void main() {
  int a = 10;
  int b = 5;

  // Arithmetic operations
  print("Addition: ${a + b}");
  print("Subtraction: ${a - b}");
  print("Multiplication: ${a * b}");
  print("Division: ${a / b}");
  print("Modulo: ${a % b}");

  // Relational operations
  print("Is a greater than b? ${a > b}");
  print("Is a equal to b? ${a == b}");

  // Logical operations
  bool isSunny = true;
  bool isWeekend = false;
  print("Is it sunny and weekend? ${isSunny && isWeekend}");
  print("Is it sunny or weekend? ${isSunny || isWeekend}");
}
