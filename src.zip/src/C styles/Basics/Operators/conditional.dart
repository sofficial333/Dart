void main()
{
  var x=null;
  var y=9;
  var z;
  var p=22;
  
  var val=x??y;
  var val2=y??z;
  var val3=p??y;

  print(val);
  print(val2);
  print(val3);
}