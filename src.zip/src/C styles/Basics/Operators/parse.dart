void main()
{
  var a=num.parse('25.55');
  var b=num.parse('2.2');
  print(a+b);
}