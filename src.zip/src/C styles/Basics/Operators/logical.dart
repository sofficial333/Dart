void main()
{
  bool a=false, b=true;

  print(a&&b);
  print(a||b);
  print(!a);
}