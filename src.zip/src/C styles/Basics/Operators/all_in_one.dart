void main()
{
  int a=10, b=5;
  print('a+b= ${a+b}'); //Arithmentic operators
  print('a-b= ${a-b}');
  print('a*b= ${a*b}');
  print('a/b= ${a/b}');
  print('a%b= ${a%b}');
  print('a~/b= ${a~/b}');

  print('a==b: ${a==b}'); //Equality
  print('a!=b: ${a==b}'); //relational
  print('a>b: ${a>b}');
  print('a<b: ${a<b}');
  print('a>=b: ${a>=b}');
  print('a<=b: ${a<=b}');

  bool x=true, y=false;  //Logical
  print('x&&y: ${x&&y}'); //and
  print('x||y: ${x||y}'); //or
  print('!y: ${!y}');      //not

  int d=0, c=1;         //Bitwise
  print('c&d: ${c&d}'); //and
  print('c|d: ${c|d}'); //or

  int e=5, f=5;   //assignment
  e=e+2;
  f+=2;
  print('e=$e, f=$f');

  e=e++;      //increement
  print('e++= $e');
}