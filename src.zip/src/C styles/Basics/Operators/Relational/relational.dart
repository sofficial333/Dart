void main()
{
  int a=1, b=1, c=2;
  print(a==b);
  print(a!=b);
  print(a>c);
  print(b<c);
  print(c<=a);
  print(b>=a);
}