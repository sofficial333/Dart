void main() {
  bool isRainy = true;
  print('Can I go out? ${!isRainy}');
}