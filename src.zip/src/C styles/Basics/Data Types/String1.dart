void main() {
  String name = 'John Doe';
  print('Name: $name');

  // Concatenation
  String greeting = 'Hello, ' + name;
  print('Greeting: $greeting');

  // Interpolation
  String interpolatedGreeting = 'Hello, $name';
  print('Interpolated Greeting: $interpolatedGreeting');

  // Length
  int length = name.length;
  print('Length: $length');

  // Upper case
  String upperCase = name.toUpperCase();
  print('Upper Case: $upperCase');

  // Lower case
  String lowerCase = name.toLowerCase();
  print('Lower Case: $lowerCase');
}
