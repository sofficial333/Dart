void main()
{
  double a=-123123123.00;
  double b=10.55465132465451324688465415;
  double c=123123123.123123;

  print('a=$a');
  print('b=$b');
  print('c=$c');
}