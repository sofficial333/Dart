main() {
  var output = '''
  a string that you \"don\'t\" have to escape
  this
  is a ....... multi-line
  heredoc string --------> example
  ''';
  print(output);
}
