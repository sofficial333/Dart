void main() {
  double num = 5.7;
  print('As int: ${num.toInt()}');
}