void main()
{
  int age=23;
  double height=5.7;

  print('Height:$height, Age: $age');
}