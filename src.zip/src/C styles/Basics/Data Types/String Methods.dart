void main() {
  String text = 'Hello World';
  print('Length: ${text.length}');
  print('Uppercase: ${text.toUpperCase()}');
}