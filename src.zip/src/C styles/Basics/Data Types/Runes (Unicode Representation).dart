void main() {
  Runes emoji = Runes('\u{1F600}');
  print(String.fromCharCodes(emoji)); // 😀
}