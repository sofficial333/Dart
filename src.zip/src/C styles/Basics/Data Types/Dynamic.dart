void main() {
  dynamic variable = "Hello";
  print(variable);

  variable = 42; // Now it's an integer
  print(variable);

  variable = 4.2; // Now it's an FLOATING POINT
  print(variable);
}
