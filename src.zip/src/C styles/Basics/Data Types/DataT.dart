void main() {
  var name = "Emma"; // inferred as String
  final int age = 30; // explicitly declared as int
  const double pi = 3.14;

  print("Name: $name");
  print("Age: $age");
  print("PI: $pi");
}