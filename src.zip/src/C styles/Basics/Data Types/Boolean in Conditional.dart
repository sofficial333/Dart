void main() {
  bool isAvailable = true;
  if (isAvailable) {
    print('The item is available!');
  } else {
    print('The item is not available!');
  }
}