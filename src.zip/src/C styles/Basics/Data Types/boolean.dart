void main()
{
  bool a=true;
  bool b=false;

  print('True:$a');
  print('False:$b');
}