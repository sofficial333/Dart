void main() {
  int x = 5;
  int y = 2;
  print('Division: ${x / y}');
  print('Modulus: ${x % y}');
}