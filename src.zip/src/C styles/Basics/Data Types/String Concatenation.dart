void main() {
  String firstName = 'Sandeep';
  String lastName = 'Kumar';
  print('Full Name: $firstName $lastName');
}