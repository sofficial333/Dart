// void main()
// {
//   var heart = '\u2665'; // Unicode for heart symbol
//   print('Heart symbol: $heart');
// }

void main()
{
  String s='a';

  print(s.runes);
}