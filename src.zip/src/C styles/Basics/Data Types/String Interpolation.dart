
void main() {
  String language = 'Dart';
  print('I am learning $language programming!');
}