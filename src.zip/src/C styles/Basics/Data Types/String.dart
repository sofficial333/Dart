void main()
{
  String S="my name is Sandeep";
  S="Kiran is my Girl friend";
  print(S);
}