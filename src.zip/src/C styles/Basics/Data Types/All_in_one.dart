  import 'dart:io';

  void main()
  {
    int score=10; //number
    double height=5.9;
    print('score:=$score, height:=$height');

    String name='sandeep'; //string
    print('name:=$name');

    bool isprogrammer =false; //boolean
    print('isProgrammer: $isprogrammer');

    List<String> color =['R','G','B','1', "1"]; //list type
    print('Colour List:=$color');

    Map<int, String> St_grd={90:'sandeep', 80:'pradeep', 70:'pooja'};//map type
    print("Map grade:=$St_grd");

    Set<int> uniqueNo={1,2,3,4,5,5};//set type
  print('NumberSet is:=$uniqueNo');

  Runes unicode='a, bc'.runes; //unicode  type
  print('Unicode:=$unicode');

  Symbol sym=#mySchool; //symbol type
  print('Symbol:=$sym');
  }