
void main() {
  List<String> fruits = ['Apple', 'Banana'];
  fruits.add('Orange');
  fruits.remove('Banana');
  print(fruits);
}
