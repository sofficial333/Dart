void main() {
  List<int> nums = [1, 2, 3];
  nums.add(4);
  print(nums);
}