void main()
{
  var lst=[1,2,2,33.3,"a"];
  print(lst);

  void main()
  {
    //var st4=<int>[1,2,2,3.3,"a"];
    //var st3=<var>[1,2,2,3.3,"b"];
    var st=[1,2,2,3.3,"a"];    //bydefault dynamic
    var st0=<dynamic>[1,2,2,3.3,"b"];
    var st1=<double>[1.1,2.2,3,3];
    var st2=<bool>[true,false];
    print(st);
    print(st0);
    print(st1);
    print(st2);
  //print(st3);
  }
}