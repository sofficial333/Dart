void main() {
  List<String> fruits = ['apple', 'banana', 'cherry'];
  print('Fruits: $fruits');

  // Add an element
  fruits.add('date');
  print('Fruits after add: $fruits');

  // Remove an element
  fruits.remove('banana');
  print('Fruits after remove: $fruits');

  // Get an element by index
  String firstFruit = fruits[0];
  print('First Fruit: $firstFruit');

  // Check if an element exists
  bool hasCherry = fruits.contains('cherry');
  print('Has Cherry: $hasCherry');
}
