void main() {
  List<int> numbers = [5, 3, 8, 1];
  numbers.sort();
  print(numbers); // [1, 3, 5, 8]
}