void main()
{
  List<String> lst=['my','name','is','sandeep','kumar'];
print(lst);
}