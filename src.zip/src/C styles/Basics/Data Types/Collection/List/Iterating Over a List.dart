void main() {
  List<int> numbers = [1, 2, 3];
  for (var number in numbers) {
    print(number);
  }
}
