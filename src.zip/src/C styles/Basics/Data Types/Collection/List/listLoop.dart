void main()
{
  List<String> fruits=['Apple','Banana','cherry'];

  for(String fruit in fruits)
    {
      print(fruit);
    }
}