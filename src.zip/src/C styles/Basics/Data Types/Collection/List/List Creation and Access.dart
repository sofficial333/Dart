void main() {
  List<int> numbers = [1, 2, 3, 4, 5];
  print('First number: ${numbers[0]}');
  print('All numbers: $numbers');
}