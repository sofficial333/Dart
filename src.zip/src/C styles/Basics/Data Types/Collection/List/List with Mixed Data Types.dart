
void main() {
  List<dynamic> mixedList = [1, 'Hello', true];
  print('Mixed List: $mixedList');
}
