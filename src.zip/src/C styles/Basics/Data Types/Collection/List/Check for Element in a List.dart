void main() {
  List<String> names = ['Alice', 'Bob'];
  print(names.contains('Alice')); // true
}