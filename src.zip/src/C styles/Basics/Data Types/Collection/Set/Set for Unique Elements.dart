void main() {
  Set<int> uniqueNumbers = {1, 2, 2, 3};
  print('Unique Numbers: $uniqueNumbers');
}