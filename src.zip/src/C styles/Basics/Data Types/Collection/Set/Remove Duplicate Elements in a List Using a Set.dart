void main() {
  List<int> numbers = [1, 1, 2, 3, 3, 4];
  Set<int> uniqueNumbers = numbers.toSet();
  print(uniqueNumbers.toList()); // [1, 2, 3, 4]
}