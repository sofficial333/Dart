void main() {
  Set<int> setA = {1, 2, 3};
  Set<int> setB = {3, 4, 5};
  print('Union: ${setA.union(setB)}');
  print('Intersection: ${setA.intersection(setB)}');
}