
void main() {
  Set<String> animals = {'Dog', 'Cat'};
  animals.add('Bird');
  animals.remove('Cat');
  print(animals);
}