void main()
{
  Set<String> vowels={'A','E','I','O','U'};

  print('vowels');
}