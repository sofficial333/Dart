void main() {
  Set<int> numbers = {1, 2, 3};
  print('Set: $numbers');
  print('Contains 2: ${numbers.contains(2)}');
}