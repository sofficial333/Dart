void main()
{
  // var st=<int>{1,2,2,3.3,"a"};
  // var st=<var>{1,2,2,3.3,"b"};
  var st=<dynamic>{1,2,2,3.3,"b"};
  var st1=<double>{1,2.2,3,3};
var st2=<bool>{true,false};
  print(st);
  print(st1);
  print(st2);
}