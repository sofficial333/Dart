
void main() {
  Set<int> nums = {1, 2, 3};
  print('Contains 2: ${nums.contains(2)}');
}
