void main()
{
  var x = 23;
  var y = 23;
  var z = 45;

  var list = <int>[];
  list.add(x);
  list.add(y);
  list.add(z);
  list.add(x);
  print(list);

  var set = <int>{};
  set.add(x);
  set.add(y);
  set.add(z);
  set.add(x);
  print(set);
}