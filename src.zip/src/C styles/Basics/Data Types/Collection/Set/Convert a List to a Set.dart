void main() {
  List<int> numbers = [1, 2, 2, 3];
  Set<int> uniqueNumbers = numbers.toSet();
  print(uniqueNumbers); // {1, 2, 3}
}
