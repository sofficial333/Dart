
void main() {
  Set<int> uniqueNumbers = {1, 2, 3, 3, 4};
  print('Unique Numbers: $uniqueNumbers');

  // Add an element
  uniqueNumbers.add(5);
  print('Unique Numbers after add: $uniqueNumbers');

  // Remove an element
  uniqueNumbers.remove(3);
  print('Unique Numbers after remove: $uniqueNumbers');

  // Check if an element exists
  bool hasTwo = uniqueNumbers.contains(2);
  print('Has Two: $hasTwo');
}
