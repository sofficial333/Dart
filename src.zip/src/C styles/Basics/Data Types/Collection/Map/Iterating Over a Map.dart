void main() {
  Map<String, int> data = {'A': 1, 'B': 2};
  data.forEach((key, value) {
    print('$key: $value');
  });
}