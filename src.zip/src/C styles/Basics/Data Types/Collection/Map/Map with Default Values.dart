void main() {
  Map<String, String> countries = {'India': 'Delhi'};
  print(countries['USA'] ?? 'Not Found'); // Output: Not Found
}