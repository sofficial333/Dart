void main() {

  Map<String, String> mp = new Map();
  mp['course'] = "android";
  mp['location'] = 'ducat';

  print(mp.values);
  print(mp.keys);
  print(mp);
}