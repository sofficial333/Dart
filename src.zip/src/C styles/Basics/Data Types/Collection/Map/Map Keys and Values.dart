  void main() {
    Map<String, String> capitals = {'India': 'Delhi', 'USA': 'Washington'};
    print('Keys: ${capitals.keys}');
    print('Values: ${capitals.values}');
  }
