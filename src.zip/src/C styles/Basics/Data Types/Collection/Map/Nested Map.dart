void main() {
  Map<String, Map<String, int>> students = {
    'Class1': {'Alice': 90, 'Bob': 80},
    'Class2': {'John': 85, 'Jane': 95},
  };
  print('Class1: ${students['Class1']}');
}
