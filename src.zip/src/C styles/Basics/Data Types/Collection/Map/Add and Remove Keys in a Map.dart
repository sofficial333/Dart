void main() {
  Map<String, String> capitals = {'India': 'Delhi'};
  capitals['USA'] = 'Washington';
  capitals.remove('India');
  print(capitals);
}