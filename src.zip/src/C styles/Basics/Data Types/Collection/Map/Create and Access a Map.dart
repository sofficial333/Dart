void main() {
  Map<String, int> scores = {'Alice': 85, 'Bob': 90};
  print('Alice\'s score: ${scores['Alice']}');
}