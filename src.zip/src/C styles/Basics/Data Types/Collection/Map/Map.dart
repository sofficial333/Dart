// void main()
// {
//   Map<int, String> student = {1: 'sandeep', 2: 'pradeep', 3: 'pooja'};
//
//   print(student);
// }

void main() {
  Map student = {1: 'sandeep', 2: 'pradeep', 3: 'pooja'}; //kay:value

  print(student);


  Map<String, String> mp = new Map();
  mp['course'] = "android";
  mp['location'] = 'ducat';
  print(mp.values);
  print(mp.keys);
  print(mp);
}