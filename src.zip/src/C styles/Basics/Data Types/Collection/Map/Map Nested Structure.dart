
void main() {
  Map<String, Map<String, int>> nestedMap = {
    'Class1': {'Alice': 90, 'Bob': 85},
    'Class2': {'John': 80, 'Doe': 95}
  };
  print('Class1 Marks: ${nestedMap['Class1']}');
}
