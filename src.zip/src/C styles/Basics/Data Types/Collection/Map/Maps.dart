void main() {
  Map<String, int> personData = {'John': 30, 'Alice': 25};
  print('Person Data: $personData');

  // Add a new entry
  personData['Bob'] = 40;
  print('Person Data after add: $personData');

  // Update an existing entry
  personData['John'] = 31;
  print('Person Data after update: $personData');

  // Remove an entry
  personData.remove('Alice');
  print('Person Data after remove: $personData');

  // Check if a key exists
  bool hasJohn = personData.containsKey('John');
  print('Has John: $hasJohn');
}
