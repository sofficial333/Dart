void main() {
  Map<String, int> age = {'Alice': 25, 'Bob': 30};
  print('Alice\'s age: ${age['Alice']}');
}