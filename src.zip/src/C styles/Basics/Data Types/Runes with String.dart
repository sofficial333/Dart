void main() {
  String heart = '\u2764'; 
  String smiley = '\u{1F642}';
  print('I $heart Dart $smiley');
}