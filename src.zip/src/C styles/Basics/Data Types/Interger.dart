void main()
{
  int a=30, b=40, c=71;

  int d=(a*b)%c;
  print('$d');
}