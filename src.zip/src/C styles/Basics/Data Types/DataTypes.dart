void main() {
  int age = 25;   //integer types
  double price = 99.99; //Double types
  String name = "John";  //String types
  bool isLoggedIn = true;  //Boolean types types
  List<int> numbers = [1, 2, 3, 4];  //List  types
  Map<String, String> user = {'name': 'Alice', 'country': 'USA'};  //Map types types

  print("Age: $age");
  print("Price: $price");
  print("Name: $name");
  print("Is Logged In: $isLoggedIn");
  print("Numbers: $numbers");
  print("User Info: $user");
}
