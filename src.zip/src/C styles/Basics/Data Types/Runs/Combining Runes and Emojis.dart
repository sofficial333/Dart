
void main() {
  Runes heart = Runes('\u2764');
  Runes smile = Runes('\u{1F604}');
  print(String.fromCharCodes(heart) + ' ' + String.fromCharCodes(smile)); // ❤️ 😄
}