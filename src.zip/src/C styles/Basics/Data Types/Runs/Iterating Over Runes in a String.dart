void main() {
  String text = 'Hello 😊';
  text.runes.forEach((int rune) {
    print(String.fromCharCode(rune));
  });
}