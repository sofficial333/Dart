void main()
{
  String a='12', b='87';
double c=int.parse(a)+double.parse(b);
print(c);
}