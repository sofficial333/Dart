void main()
{
  int age=30;
  print(age);
}