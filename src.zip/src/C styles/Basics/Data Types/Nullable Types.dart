void main() {
  String? nullableName; // This can hold a String or null

  if (nullableName == null) {
    print('Name is NULL');
  } else {
    print('Name: $nullableName');
  }
}
