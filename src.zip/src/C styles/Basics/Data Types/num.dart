void main() {
  int a = 10;
  double b = 3.14;
  print('Sum: ${a + b}');
  print('Multiplication: ${a * b}');
}