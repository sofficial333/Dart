void main() {
  bool isSunny = true;
  bool isWeekend = false;
  print('Can I go out? ${isSunny && isWeekend}');
}