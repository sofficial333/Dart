void main() {
  // Declare variables(age, height, name, isStudent) of different types
  int age = 25;
  double height = 5.9;
  String name = "Alic";
  bool isStudent = true;

  // Output their values
  print("Name: $name");
  print("Age: $age");
  print("Height: $height");
  print("Is a student? $isStudent");
}
