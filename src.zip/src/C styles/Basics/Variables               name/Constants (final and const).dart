void main() {
  final String country = "Canada";  // Can be set once, and not changed
  const double pi = 3.14159;        // Compile-time constant

  print("Country: $country");
  print("Value of Pi: $pi");

  // Trying to reassign a final or const variable will throw an error
  // country = "USA";  // This will cause an error
}
