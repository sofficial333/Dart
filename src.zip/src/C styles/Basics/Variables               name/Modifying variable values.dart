void main() {
  int score = 50;
  print("Initial Score: $score");

  // Modifying the value of a variable
  score = 75;
  print("Updated Score: $score");
}
