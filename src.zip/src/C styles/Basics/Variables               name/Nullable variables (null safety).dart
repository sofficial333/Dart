void main() {
  String? address;  // This variable can be null
  address = null;
  print("Address: $address");
}