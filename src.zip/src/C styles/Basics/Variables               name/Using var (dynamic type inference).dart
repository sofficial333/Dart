void main() {
  var city = "New York";  // Dart automatically infers the type as String
  var temperature = 72.5; // Dart infers this as a double

  print("City: $city");
  print("Temperature: $temperature °F");
}
