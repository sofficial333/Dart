void main()
{
  var f=const[];

  f=[12];
  // f=2.23;

  print(f);

}