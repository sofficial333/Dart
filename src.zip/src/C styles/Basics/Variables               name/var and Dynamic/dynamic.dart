void main() {
  dynamic a;
  a = 22; //int
  a = 2.22; //double
  a = "ddd"; //string
  a = true; //boolean

  print(a);
}