void main()
{
  const pi=22/7;
  const name='san';
  // pi=2;
  // const pi=3.142857142857143;
print(pi);
print(name);
}