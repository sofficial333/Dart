void main()
{
  final name='Sandeep';
  final pi=3.14;
  // name='pooja';
  print(name);
  print(pi);
}