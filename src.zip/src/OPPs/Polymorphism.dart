class Animal {
  void sound() {
    print("Animal makes a sound.");
  }
}

class Dog extends Animal {
  @override
  void sound() {
    print("Dog barks.");
  }
}

class Cat extends Animal {
  @override
  void sound() {
    print("Cat meows.");
  }
}

void main() {
  Animal dog = Dog();  // Polymorphism: Dog treated as Animal
  Animal cat = Cat();  // Polymorphism: Cat treated as Animal

  dog.sound();  // Dog's version of sound
  cat.sound();  // Cat's version of sound
}
