// Abstract class
abstract class Shape {
  // Abstract method
  double area();

  void display() {
    print("This is a shape.");
  }
}

// Class extending abstract class
class Circle extends Shape {
  double radius;

  Circle(this.radius);

  // Implementing the abstract method
  @override
  double area() => 3.14 * radius * radius;
}

void main() {
  Circle circle = Circle(5);
  circle.display();
  print("Area of the circle: ${circle.area()}");
}
