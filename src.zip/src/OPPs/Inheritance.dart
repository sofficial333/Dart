// Parent class
class Animal {
  void eat() {
    print("Animal is eating.");
  }
}

// Child class inheriting from Animal
class Dog extends Animal {
  void bark() {
    print("Dog is barking.");
  }
}

void main() {
  Dog dog = Dog();
  dog.eat();  // Method from Animal class
  dog.bark(); // Method from Dog class
}
