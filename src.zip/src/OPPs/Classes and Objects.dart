class Car {
  String brand;
  int year;

  // Constructor
  Car(this.brand, this.year);

  // Method
  void displayInfo() {
    print("Brand: $brand, Year: $year");
  }
}

void main() {
  // Creating objects
  Car car1 = Car("Toyota", 2015);
  Car car2 = Car("Honda", 2020);

  // Accessing methods of the class using objects
  car1.displayInfo();
  car2.displayInfo();
}
