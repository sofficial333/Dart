class Printer {
  void printDocument() {
    print("Printing document...");
  }
}

class Scanner {
  void scanDocument() {
    print("Scanning document...");
  }
}

// Multiple inheritance-like behavior using interfaces
class AllInOnePrinter implements Printer, Scanner {
  @override
  void printDocument() {
    print("All-in-one printer printing...");
  }

  @override
  void scanDocument() {
    print("All-in-one printer scanning...");
  }
}

void main() {
  AllInOnePrinter printer = AllInOnePrinter();
  printer.printDocument();
  printer.scanDocument();
}
