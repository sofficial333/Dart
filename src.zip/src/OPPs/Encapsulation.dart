class BankAccount {
  // Private variable
  double _balance = 0;

  // Public method to access the private variable
  void deposit(double amount) {
    _balance += amount;
  }

  // Getter to access private variable
  double get balance => _balance;
}

void main() {
  BankAccount account = BankAccount();
  account.deposit(1000);
  print("Balance: \$${account.balance}");
}
