void main()
{
  print("Hello");
}